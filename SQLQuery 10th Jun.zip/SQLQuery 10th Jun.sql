/*
User Defined Function (UDF): is precomplied code
	-will always return the value 
	-DML cannot be use in function on base table 
	-can be use as a table 
	-can be use in expression 	  
Procedure: is precompiled code   
	-procedure may or may not return value 
	-procedure can return multiple values/tables
	-any sql command can be impleted in procedure 
	-pramater type:
			in		: default 
			out 

Trigger : is type of procedure which invokes/execute automatically whene DML(insert , delete, update) command will run on a table
	Types of trigger:
		-instead of / before 
				-insert
				-update
				-delete
		-after   
				-insert
				-update
				-delete
		
		Trigger magic or virtual or temp. table:
				inserted  : after insert, update (new value) event inserted table will create

				deleted   : after delete, udpate (old value) event 
	Usecase of Trigger:
		-to store the change logs 
			
*/

use hrms 
--custom function 

create function inc_tax
(
@amt int
)
returns int
as
begin
	
	declare @out as int
	if @amt > 300000		
	begin
			set @out = @amt *.15 
	end
	else
	begin

			set @out = @amt *.05 
	end

	return @out 
			
end




---
select dbo.inc_tax(112334)
select *,dbo.inc_tax(salary) as tax from C_Employee


--procedure or stored procedreu (sp)
create proc proc_emp
as
begin

			select * from emp_copy_gender

end

--With paramter 
create proc proc_emp_action
(
@gender varchar(10),
@status varchar(20)
)
as
begin

			insert into emp_copy_gender
			values(@gender,@status)

end

--With paramter , optional parameter
create proc proc_emp_action2
(
@gender varchar(10),
@status varchar(20) = ''
)
as
begin
			
			IF @status =''
			begin
					insert into emp_copy_gender
					values(@gender,'NA')
			end
			else
			begin
					insert into emp_copy_gender
					values(@gender,@status)
			end


end

----out parameter
create proc proc_emp_action3
(
@gender varchar(10),
@count int out 
)
as
begin
			select @count = count(*) from emp_copy_gender 
			where gender = @gender
			
end





--call to proc
proc_emp
exec proc_emp
execute proc_emp

proc_emp_action 'Female','Inactive'

proc_emp_action2 'Female','Active'

--call 
declare @count as int
execute proc_emp_action3 'Female',@count output
if @count % 2 = 0 
begin

	select 'even count'
end
else
begin
	select 'odd count'
end

/*
Trigger :

*/
select * from users where id =2
select * from users_log where id =2
order by action_date desc 


update users
set pwd ='ABD'
where id = 2


create trigger trg_update 
on users
after update
as
begin
		insert into users_log(id,name,email,time_stamp,pwd,action_type,action_date)
		SELECT *,'U',GETDATE() from deleted 
end


create trigger trg_ins 
on users
after insert
as
begin
		insert into users_log(id,name,email,time_stamp,pwd,action_type,action_date)
		SELECT *,'I',GETDATE() from inserted
end






