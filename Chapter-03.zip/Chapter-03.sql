
use hrms 

/*
top			: return top given rows  (ms sql server)
		    limit (oracle, mys sql server)
distinct   : return unique rows (combination of multiple rows)
		   

select into		: create a new table with data from existing table

Subquery		: is nested query (query inside query)

intersect		: return common rows (matching rows in both the tables)
			    : table structure should be same 

except			: return rows which is not present in 2nd table 
			    : table structure should be same 

union		   : to merge two or more than two tables  (return unique rows)

union all      :  to merge two or more than two tables  (return all  rows)

contraints     : is properties of column
===========================================
There are following contraints:
-primary key		: 
					-allow unique value
					-not allow null value 
					-physically sorted ( 1 , 10)
					-only one primary can be created on a table 
-foreign key		: is referential column from other table for example:
					employee (eid -pk)
					salary (eid - fk)
					-allow only those value which is avaiable in primary table
					-also allow duplicate value, and null value 

						
-unique				: is allow unique value(no duplicate)
				    : single null
					: we can create multiple unique key on a table 

-not null			: madatory field	(cannot be null)
-null				: optional field for data 

-default			: save/insert specified data automatically when user will not pass any value 

-check				: allow the value from given list 




*/
--top			: return top given rows
select * from Employee
select top 2 * from Employee

--from buttom
select top 2 * from Employee order by eid desc


--distinct   : return unique rows (combination of multiple rows)
select distinct * from employee
select distinct gender from employee
select distinct  fname,gender,STATUS_ID from employee



--select into		: create a new table with data from existing table
select * from Employee

select * into emp_copy_null from Employee where eid is null

select DISTINCT GENDER,STATUS_ID into emp_copy_gender from Employee 

select * from emp_copy_null
select * from emp_copy_gender

--insert into existing table
insert into emp_copy_null
select * from Employee 


--Subquery		: is nested query (query inside query)


---show top 3 highest 
select top 3 * from employee order by slry  desc 

--show 3rd highest  salary 
select top 1 * from 
	(select top 3 * from employee order by slry  desc ) a
order by slry asc 
 

 --show 4th lowest 
select top 1 * from 
	(select top 4 * from employee order by slry  asc ) a
order by slry desc
 

/*
PRODUCT 
-----
PID PNAMME   PPRICE   SPRICE 
1   IPHONE   56000    72000
2   DOVE     40      45


TRANSACTION
------------
TID  PID  TRAN_TYPE   QUANTITY  
1    2     P          100
2    2     P          50
3    2     S          90
4    1     P          1000
5    2     S           10
6    1     S          100
7    1     P          50


OUTPUT:
-----
PID PNAME TOTAL_QUANTITY_PURCHASE  TOTAL_QUANTITY_SOLD   QUANTITY_IN_STOCK    TOTAL_PUCHASE_AMT_FOR_SOLD_PRODUCT  TOTAL_PROFIT_FOR_SOLD_PRODUCT


*/



--intersect		: return common rows (matching rows in both the tables)

select * from emp_copy_null
intersect
select * from employee 



--except			: return rows which is not present in 2nd table 

select * from employee  
except
select * from emp_copy_null

--delete from emp_copy_null where eid is null 


--union		   : to merge two or more than two tables  (return unique rows)
select * from employee    -- 1, 2 , 3 , 5
union 
select * from emp_copy_null  -- 1, 9, 10 
							--  union : 1 2 3 5 9 10 
							-- intersect: 1 	

select eid,fname from employee    -- 1, 2 , 3 , 5
union 
select eid,fname from emp_copy_null  -- 1, 9, 10 


								
--union all      : : to merge two or more than two tables  (return all  rows)
select * from employee    -- 1, 2 , 3 , 5
union all
select * from emp_copy_null  -- 1, 9, 10 



select eid,fname from employee    -- 1, 2 , 3 , 5
union  all
select eid,fname from emp_copy_null  -- 1, 9, 10 




/* 
	constraints 
*/

create table users_table
(
id int primary key,
fname varchar(30) not null,
lname  varchar(30) null,
email varchar(30) unique,
gender varchar(10) check  (gender in ('male','female')) default 'Other',
create_date  datetime default getdate(),
status_id varchar(10) default 'Active'
)

insert into users_table(id,fname)
values(10,'Raman')


insert into users_table(id,fname,email)
values(1,'Raman','raman@gmail.com')


insert into users_table(id,fname,email,gender)
values(3,'MONIKA','MONIKA@gmail.com','FEMALE')


select * from users_table



--foreign key
create table user_salary
(
id int foreign key references users_table(id),
basic int,
hra int
)

insert into user_salary
values(1,44544,3333)

insert into user_salary(basic,hra)
values(445444,3333)

