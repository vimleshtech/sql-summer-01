/*
-Functions   
	-String
	-Date
	-Maths
	-Type Casting or Conversion 
	-miscellaneous
-Join and it's Type
	-inner join
	-outer join /full outer join 
		-left join
		-right join
	-cross join 
	-self join 

-view 

-CTE	
*/


-- Functions   
-- String:
select fname, len(fname) from employee --return count of chars including space
select fname, upper(fname) from employee --convert to upper case
select fname, lower(fname) from employee --convert to lower  case
select fname, ltrim(fname) from employee  --remove extra space
select fname, rtrim(fname) from employee  --remove extra space
select fname, replace(fname,'is','are') from employee --find the existing char and replace with new
select fname, left(fname,3) from employee  --return from left
select fname, right(fname,2) from employee --return from right
select fname, CHARINDEX('is',fname)  from employee --find a 
select concat(fname,' ',lname) from Employee

-- Date
select getdate()

select DATEPART(yyyy, getdate())
select DATEPART(mm, getdate())
select DATEPART(day, getdate())
select DATEPART(QUARTER, getdate())
select DATEPART(DAYOFYEAR, getdate())
select DATEPART(WEEKDAY, getdate())  --1  sunday,  2 monday 

select DATEADD(yyyy,2,getdate())
select DATEADD(month,20,getdate())
select DATEADD(day,-10000,getdate())

select DATEDIFF(YEAR,'1990-01-11',GETDATE())
select DATEDIFF(DAY,'1990-01-11',GETDATE())
select DATEDIFF(HOUR,'1990-01-11',GETDATE())


--Maths
SELECT SQRT(9) 
SELECT SQRT(EID) FROM EMPLOYEE
SELECT POWER(EID,3) FROM EMPLOYEE

SELECT ROUND(9.334444,1) FROM EMPLOYEE

SELECT ROUND(SQRT(EID),1) FROM EMPLOYEE

SELECT ROUND(EID,2) FROM EMPLOYEE
SELECT ROUND(EID,2) FROM EMPLOYEE

SELECT MAX(EID),MIN(EID),SUM(EID),AVG(EID),stdev(EID) FROM EMPLOYEE


-- Type Casting or Conversion 
select convert(varchar, 1)+'a'
select cast(1 as varchar)+'a'

select convert(varchar,getdate(),101)
select convert(varchar,getdate(),102)
select convert(varchar,getdate(),103)
select convert(varchar,getdate(),104)
select convert(varchar,getdate(),106)
select convert(varchar,getdate(),107)
select convert(varchar,getdate(),107)
select convert(varchar,getdate(),112)

-- miscellaneous
select ascii('a')

/*
-Join : to merge two or more than two tables 
      : at least one column should be same in both the tables
There are following types of join:	   
	-inner join	: return common rows 
	-outer join /full outer join: return all rows from both tables
		-left join  : return all rows from left table and matching from right table 
		   
		-right join : return all from right table and matching from left table 
	
	-Other Types of join
		-cross join    : is also knonwn as cartisan product
			       - cross is not recommended (this impact to sql query performance)
		-self join     : multiple instance of same table(join with same table) 




*/



select * from employee

select * from salary



--inner join 
select e.eid,e.fname,e.lname,s.basic
from employee as e inner join salary as s
	on e.eid = s.eid

--default join = inner join 
select e.eid,e.fname,e.lname,s.basic
from employee as e  join salary as s
	on e.eid = s.eid


--full outer join 
select e.eid,e.fname,e.lname,s.basic
from employee as e full outer join salary as s
	on e.eid = s.eid


--left join / left outer join 
select e.eid,e.fname,e.lname,s.basic
from employee as e left outer join salary as s
	on e.eid = s.eid


--right join / right outer join 
select e.eid,e.fname,e.lname,s.basic
from employee as e right outer join salary as s
	on e.eid = s.eid

--cross join 
select * from employee,salary
where employee.eid = salary.eid 

select employee.fname,employee.dob, salary.basic 
from employee,salary
where employee.eid = salary.eid 

--self join 
select * from j_employee
--output: eid name mgrid  mgrname 

select e.eid,e.name , e.MGR_ID, m.name
from j_employee as e left join j_employee as m	
	on e.mgr_id = m.eid 


/*
view : is virtual table which contains structure but not data 
     : view is also considered as wrapper of table
	 : view can be used as table 
Example:
*/

create view v_emp_details
as
select e.eid,e.name , e.MGR_ID, m.name as mgr_name
from j_employee as e left join j_employee as m	
	on e.mgr_id = m.eid 

select * from v_emp_details

insert into v_emp_details(name)
values('test')



--now allowed
insert into v_emp_details(name,MGR_ID,mgr_name)
values('test',1,'ff')



